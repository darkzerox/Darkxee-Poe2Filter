#!/bin/bash
echo "========================================"
echo "    POE2 Filter Installer"
echo "========================================"
echo.
echo "กำลังเปิด installer..."
./POE2FilterInstaller --gui
echo.
echo "การติดตั้งเสร็จสิ้น"
